# ATS v1.7.0 — รายการไฟล์ทั้งหมด

ตรวจสอบเมื่อ 31 ก.ค. 2569 · ทุกชุดตรวจแล้วว่าเวอร์ชันตรงกัน

---

## ชุดติดตั้ง (ใช้กับ ats-deploy.sh)

| ไฟล์ | ติดตั้งไปที่ | เวอร์ชัน |
|---|---|---|
| `ats-api.zip` | `~/ats-api/` | 1.7.0 |
| `hr-console.zip` | `mgccareer.com/hr/index.html` | 1.7.0 |
| `careers-site.zip` | `mgccareer.com/careers/index.html` | 1.7.0 |
| `evaluate-site.zip` | `mgccareer.com/evaluate/index.html` | 1.7.0 |
| `portal-site.zip` | `mgccareer.com/index.html` | 1.7.0 |

## สคริปต์จัดการ

| ไฟล์ | หน้าที่ |
|---|---|
| `deploy-scripts.zip` | ติดตั้ง · ย้อนกลับ · ลบเว็บเก่า พร้อมคู่มือ |

## ชุดกู้คืนฉุกเฉิน

| ไฟล์ | หน้าที่ |
|---|---|
| `mgccareer-restore.zip` | โครงสร้างเว็บครบ 4 หน้า ตรงกับ v1.7.0 |
| `อ่านก่อน-วิธีกู้คืน.md` | ขั้นตอนกู้คืนทีละขั้น |

---

## Migration ฐานข้อมูล — เรียงตามลำดับที่ต้องรัน

| เวอร์ชัน | ไฟล์ | เนื้อหา |
|---|---|---|
| v1.0 | `ats_mariadb_01_tables.sql` | ตารางหลัก 23 ตาราง |
| v1.0 | `ats_mariadb_02_triggers.sql` | ทริกเกอร์บังคับกติกา |
| v1.0 | `ats_mariadb_03_optional_checks.sql` | ข้อตรวจเสริม |
| v1.0 | `ats_seed_data.sql` | ข้อมูลตั้งต้น (สิทธิ์ บทบาท) |
| v1.1 | `ats_migration_legal_hold.sql` | ระงับการลบข้อมูล |
| v1.2 | `ats_migration_interview.sql` | ระบบสัมภาษณ์ |
| v1.3 | `ats_migration_attendance.sql` | ยืนยันเข้าร่วมสัมภาษณ์ |
| v1.4 | `ats_migration_evaluator_user.sql` | ผูกผู้ประเมินกับบัญชี |
| v1.5 | `ats_migration_segment.sql` | กลุ่มธุรกิจ 3 ชั้น |
| v1.6 | `ats_migration_reschedule.sql` | ขอเลื่อนนัด |
| v1.7 | `ats_migration_posting_lifecycle.sql` | ควบคุมวงจรชีวิตประกาศ |

**สถานะ: ติดตั้งครบทั้ง v1.0–v1.7 แล้ว** (ยืนยัน 30 ก.ค. 2569)

## เครื่องมือตรวจสอบ

| ไฟล์ | ใช้ทำอะไร |
|---|---|
| `ats_check_installed_version.sql` | ตรวจว่าฐานข้อมูลติดตั้งถึงเวอร์ชันไหน |
| `ats_check_version.sql` | ตรวจว่า MariaDB รองรับ schema ไหม (ใช้ตอนตั้งระบบใหม่) |
| `ats_verify_db_shared_hosting.sql` | ตรวจโครงสร้างฐานข้อมูลครบถ้วน |
| `ats_smoke_test_v2.sql` | ทดสอบการทำงานของกติกาต่าง ๆ |

## ไฟล์ช่วยงาน

| ไฟล์ | ใช้ทำอะไร |
|---|---|
| `ats_seed_test_postings.sql` | สร้างตำแหน่งทดสอบให้ทุกบริษัท + คำสั่งลบทิ้ง |
| `ตัวอย่าง-ใบสมัคร.html` | ตัวอย่างแบบฟอร์มพิมพ์ |
| `ats_project_status.md` | บันทึกความคืบหน้าโครงการ |
| `ats-secrets-setup.md` | วิธีตั้งค่าความปลอดภัย |

---

## ไฟล์เก่าที่ไม่ใช้แล้ว — เก็บไว้อ้างอิงเท่านั้น

ไฟล์เหล่านี้ถูกแทนที่ด้วยรุ่นใหม่แล้ว **ห้ามนำไปรันบนระบบจริง**

- `ats_schema_phase0_1.sql` · `ats_schema_phase0_1_mysql.sql` · `ats_schema_phase0_1_mariadb.sql`
  (รวมเป็น `ats_mariadb_01/02/03` แล้ว)
- `ats_patch_generated_column.sql` (แก้ปัญหาที่ไม่มีแล้วในโครงสร้างปัจจุบัน)
- `ats_verify_db.sql` · `ats_verify_db.sh` · `ats_smoke_test.sql`
  (แทนที่ด้วยรุ่น `_v2` และ `_shared_hosting`)
- `ats-applicant-form-prototype.jsx` (ต้นแบบก่อนสร้างของจริง)

---

## วิธีตรวจว่าที่ติดตั้งอยู่เป็น v1.7.0 จริง

**ฐานข้อมูล** — phpMyAdmin รัน `ats_check_installed_version.sql`

**API** — เปิด `mgccareer.com/ats/health` ดูค่า `"version":"1.7.0"`

**หน้า HR** — มุมขวาบนข้างปุ่มออกจากระบบ ขึ้น `v1.7.0`

**อีก 3 หน้า** — เปิด view-source ดูบรรทัดบนสุด จะมีหมายเหตุบอกเวอร์ชัน
หรือใช้คำสั่งใน Terminal

```bash
for p in "" careers/ hr/ evaluate/; do
  echo -n "$p : "
  curl -s "https://mgccareer.com/$p" | grep -o "UI_VERSION = '[^']*'" | head -1
done
```
